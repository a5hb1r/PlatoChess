import { useState, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  ChevronRight,
  Trophy,
  Target,
  Lightbulb,
  CheckCircle,
  XCircle,
  SkipForward,
  RotateCcw,
  Flame,
  Zap,
  Shield,
  Crown,
  Swords,
} from "lucide-react";
import { Link } from "react-router-dom";
import { Chess, Square } from "chess.js";
import { ChessSounds } from "@/lib/sounds";

// --- Piece SVGs ---
const PIECE_URLS: Record<string, Record<string, string>> = {
  w: {
    k: "https://upload.wikimedia.org/wikipedia/commons/4/42/Chess_klt45.svg",
    q: "https://upload.wikimedia.org/wikipedia/commons/1/15/Chess_qlt45.svg",
    r: "https://upload.wikimedia.org/wikipedia/commons/7/72/Chess_rlt45.svg",
    b: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Chess_blt45.svg",
    n: "https://upload.wikimedia.org/wikipedia/commons/7/70/Chess_nlt45.svg",
    p: "https://upload.wikimedia.org/wikipedia/commons/4/45/Chess_plt45.svg",
  },
  b: {
    k: "https://upload.wikimedia.org/wikipedia/commons/f/f0/Chess_kdt45.svg",
    q: "https://upload.wikimedia.org/wikipedia/commons/4/47/Chess_qdt45.svg",
    r: "https://upload.wikimedia.org/wikipedia/commons/f/ff/Chess_rdt45.svg",
    b: "https://upload.wikimedia.org/wikipedia/commons/9/98/Chess_bdt45.svg",
    n: "https://upload.wikimedia.org/wikipedia/commons/e/ef/Chess_ndt45.svg",
    p: "https://upload.wikimedia.org/wikipedia/commons/c/c7/Chess_pdt45.svg",
  },
};

interface Puzzle {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: "easy" | "medium" | "hard";
  fen: string;
  playerColor: "w" | "b";
  solution: string[]; // Alternating player/opponent moves in UCI (e.g. "e7e8q")
  hint: string;
}

const PUZZLES: Puzzle[] = [
  // === FORKS ===
  {
    id: "fork-1",
    title: "Knight Fork",
    description: "Fork the king and queen with your knight.",
    category: "Fork",
    difficulty: "easy",
    fen: "r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4",
    playerColor: "w",
    solution: ["h5f7"],
    hint: "Look at f7 — it's only defended by the king.",
  },
  {
    id: "fork-2",
    title: "Royal Fork",
    description: "Find the knight fork winning material.",
    category: "Fork",
    difficulty: "medium",
    fen: "r3k2r/ppp2ppp/2n1b3/3q4/3P4/2N2N2/PPP2PPP/R1BQR1K1 w kq - 0 10",
    playerColor: "w",
    solution: ["f3e5", "c6e5", "d4e5"],
    hint: "Can your knight land on a central square attacking multiple pieces?",
  },
  {
    id: "fork-3",
    title: "Pawn Fork",
    description: "Use a pawn to fork two pieces.",
    category: "Fork",
    difficulty: "easy",
    fen: "r1bqkbnr/pppppppp/8/8/3nB3/8/PPPP1PPP/RNBQK1NR w KQkq - 0 1",
    playerColor: "w",
    solution: ["d2d3"],
    hint: "A simple pawn move attacks two pieces.",
  },
  // === PINS ===
  {
    id: "pin-1",
    title: "Absolute Pin",
    description: "Pin the knight to the king.",
    category: "Pin",
    difficulty: "easy",
    fen: "rnbqkb1r/pppppppp/5n2/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 1 2",
    playerColor: "w",
    solution: ["f1b5"],
    hint: "Your bishop can pin a piece along the diagonal.",
  },
  {
    id: "pin-2",
    title: "Winning the Pinned Piece",
    description: "The knight is pinned. Win it!",
    category: "Pin",
    difficulty: "medium",
    fen: "r1bqk2r/pppp1ppp/2n2n2/1B2p3/4P3/5N2/PPPP1PPP/RNBQ1RK1 w kq - 4 4",
    playerColor: "w",
    solution: ["b5c6", "d7c6"],
    hint: "Capture the pinned piece.",
  },
  // === SKEWERS ===
  {
    id: "skewer-1",
    title: "Bishop Skewer",
    description: "Skewer the king and rook with your bishop.",
    category: "Skewer",
    difficulty: "medium",
    fen: "6k1/5ppp/8/8/8/2B5/5PPP/4r1K1 w - - 0 1",
    playerColor: "w",
    solution: ["c3f6"],
    hint: "Attack the king along the diagonal — what's behind it?",
  },
  // === BACK RANK ===
  {
    id: "backrank-1",
    title: "Back Rank Mate",
    description: "Deliver checkmate on the back rank.",
    category: "Back Rank",
    difficulty: "easy",
    fen: "6k1/5ppp/8/8/8/8/5PPP/4R1K1 w - - 0 1",
    playerColor: "w",
    solution: ["e1e8"],
    hint: "The king is trapped — can you deliver a check on the 8th rank?",
  },
  {
    id: "backrank-2",
    title: "Back Rank with Sacrifice",
    description: "Sacrifice to set up a back rank mate.",
    category: "Back Rank",
    difficulty: "hard",
    fen: "2r3k1/5ppp/8/8/8/8/4QPPP/1R4K1 w - - 0 1",
    playerColor: "w",
    solution: ["e2e8", "c8e8", "b1e1", "e8e1"],
    hint: "What if you sacrifice your queen first?",
  },
  // === DISCOVERED ATTACKS ===
  {
    id: "discovered-1",
    title: "Discovered Check",
    description: "Move one piece to unleash an attack from another.",
    category: "Discovery",
    difficulty: "medium",
    fen: "r1bqkb1r/pppppppp/2n5/8/3nP3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1",
    playerColor: "w",
    solution: ["f3d4", "c6d4"],
    hint: "Moving your knight reveals an attack.",
  },
  // === MATE IN 1 ===
  {
    id: "mate1-1",
    title: "Queen Mate",
    description: "Deliver checkmate in one move.",
    category: "Mate in 1",
    difficulty: "easy",
    fen: "k7/8/1K6/8/8/8/8/1Q6 w - - 0 1",
    playerColor: "w",
    solution: ["b1a2"],
    hint: "Where can your queen deliver check with no escape?",
  },
  {
    id: "mate1-2",
    title: "Rook Mate",
    description: "Checkmate with your rook.",
    category: "Mate in 1",
    difficulty: "easy",
    fen: "2k5/8/2K5/8/8/8/8/R7 w - - 0 1",
    playerColor: "w",
    solution: ["a1a8"],
    hint: "The king is confined — deliver check on the back rank.",
  },
  {
    id: "mate1-3",
    title: "Bishop & Queen Mate",
    description: "Use your bishop and queen together.",
    category: "Mate in 1",
    difficulty: "easy",
    fen: "r1bqk2r/pppp1Bpp/2n2n2/2b1p3/4P3/8/PPPP1PPP/RNBQK1NR w KQkq - 0 1",
    playerColor: "w",
    solution: ["d1h5"],
    hint: "Your bishop already controls a key diagonal.",
  },
  // === MATE IN 2 ===
  {
    id: "mate2-1",
    title: "Smothered Mate",
    description: "Deliver the classic smothered mate pattern.",
    category: "Mate in 2",
    difficulty: "hard",
    fen: "r1b3kr/ppp3pp/8/4N3/2q5/8/PPP1QPPP/R1B2RK1 w - - 0 1",
    playerColor: "w",
    solution: ["e2g4", "g8h8", "e5f7"],
    hint: "Force the king into the corner, then smother it.",
  },
  {
    id: "mate2-2",
    title: "Queen Sacrifice Mate",
    description: "Sacrifice your queen to force checkmate.",
    category: "Mate in 2",
    difficulty: "hard",
    fen: "r4rk1/ppp2ppp/8/3q4/8/1B6/PPP2PPP/R4RK1 w - - 0 1",
    playerColor: "w",
    solution: ["f1f7"],
    hint: "The f7 square is weak — attack it.",
  },
  // === TACTICS - REMOVING THE DEFENDER ===
  {
    id: "remove-def-1",
    title: "Remove the Defender",
    description: "Capture the piece that guards a key square.",
    category: "Removing Defender",
    difficulty: "medium",
    fen: "r1b1kb1r/pppp1ppp/2n2n2/4p3/2B1P1q1/5N2/PPPP1PPP/RNBQR1K1 w kq - 0 1",
    playerColor: "w",
    solution: ["c4f7", "e8f7", "f3g5", "f7g8"],
    hint: "If f7 falls, what happens next?",
  },
  // === DEFLECTION ===
  {
    id: "deflect-1",
    title: "Deflection",
    description: "Force a defending piece away from its duty.",
    category: "Deflection",
    difficulty: "hard",
    fen: "r4rk1/ppp2ppp/3b4/3Pp1q1/8/1B3N2/PPP2PPP/R2Q1RK1 w - - 0 1",
    playerColor: "w",
    solution: ["f3g5"],
    hint: "Attack with your knight — what does it threaten?",
  },
  // === ENDGAME ===
  {
    id: "endgame-1",
    title: "King & Pawn Endgame",
    description: "Promote your pawn — find the right king move.",
    category: "Endgame",
    difficulty: "medium",
    fen: "8/8/8/8/8/4K3/4P3/4k3 w - - 0 1",
    playerColor: "w",
    solution: ["e3d3"],
    hint: "Opposition is key — keep your king in front of the pawn.",
  },
  {
    id: "endgame-2",
    title: "Rook Endgame",
    description: "Cut off the enemy king with your rook.",
    category: "Endgame",
    difficulty: "medium",
    fen: "8/8/4k3/8/4P3/8/8/4K1R1 w - - 0 1",
    playerColor: "w",
    solution: ["g1g6"],
    hint: "Use your rook to cut off the king along a rank.",
  },
];

const CATEGORIES = [
  { id: "all", label: "All Puzzles", icon: Target },
  { id: "Fork", label: "Forks", icon: Zap },
  { id: "Pin", label: "Pins", icon: Shield },
  { id: "Skewer", label: "Skewers", icon: Swords },
  { id: "Back Rank", label: "Back Rank", icon: Crown },
  { id: "Mate in 1", label: "Mate in 1", icon: Trophy },
  { id: "Mate in 2", label: "Mate in 2", icon: Flame },
  { id: "Endgame", label: "Endgame", icon: Target },
];

function getSquareFromPoint(
  boardEl: HTMLElement,
  clientX: number,
  clientY: number,
  flipped: boolean
): Square | null {
  const rect = boardEl.getBoundingClientRect();
  const x = clientX - rect.left;
  const y = clientY - rect.top;
  let col = Math.floor((x / rect.width) * 8);
  let row = Math.floor((y / rect.height) * 8);
  if (flipped) {
    col = 7 - col;
    row = 7 - row;
  }
  if (col < 0 || col > 7 || row < 0 || row > 7) return null;
  return `${String.fromCharCode(97 + col)}${8 - row}` as Square;
}

const Puzzles = () => {
  const [category, setCategory] = useState("all");
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const [game, setGame] = useState<Chess | null>(null);
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [validMoves, setValidMoves] = useState<Square[]>([]);
  const [lastMove, setLastMove] = useState<{ from: Square; to: Square } | null>(null);
  const [moveIndex, setMoveIndex] = useState(0);
  const [status, setStatus] = useState<"solving" | "correct" | "wrong" | "complete">("solving");
  const [showHint, setShowHint] = useState(false);
  const [solved, setSolved] = useState<Set<string>>(new Set());
  const [streak, setStreak] = useState(0);

  // Drag state
  const [dragging, setDragging] = useState<{
    square: Square;
    piece: { color: string; type: string };
    x: number;
    y: number;
  } | null>(null);
  const [dragOver, setDragOver] = useState<Square | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);

  const filteredPuzzles = category === "all"
    ? PUZZLES
    : PUZZLES.filter((p) => p.category === category);

  const currentPuzzle = filteredPuzzles[puzzleIndex % filteredPuzzles.length];
  const flipped = currentPuzzle?.playerColor === "b";

  // Initialize puzzle
  useEffect(() => {
    if (!currentPuzzle) return;
    const g = new Chess(currentPuzzle.fen);
    setGame(g);
    setMoveIndex(0);
    setSelectedSquare(null);
    setValidMoves([]);
    setLastMove(null);
    setStatus("solving");
    setShowHint(false);
    setDragging(null);
    setDragOver(null);
  }, [currentPuzzle?.id]);

  const parseUCI = (uci: string): { from: Square; to: Square; promotion?: string } => {
    return {
      from: uci.slice(0, 2) as Square,
      to: uci.slice(2, 4) as Square,
      promotion: uci.length > 4 ? uci[4] : undefined,
    };
  };

  const executePlayerMove = useCallback(
    (from: Square, to: Square) => {
      if (!game || !currentPuzzle || status !== "solving") return;

      const expectedUCI = currentPuzzle.solution[moveIndex];
      if (!expectedUCI) return;
      const expected = parseUCI(expectedUCI);

      if (from === expected.from && to === expected.to) {
        // Correct move
        const g = new Chess(game.fen());
        const result = g.move({ from, to, promotion: expected.promotion as any });
        if (!result) return;

        // Play sound
        if (g.isCheck()) ChessSounds.check();
        else if (result.captured) ChessSounds.capture();
        else ChessSounds.move();

        setGame(g);
        setLastMove({ from, to });
        setSelectedSquare(null);
        setValidMoves([]);

        const nextMoveIdx = moveIndex + 1;

        // Check if puzzle is complete
        if (nextMoveIdx >= currentPuzzle.solution.length) {
          setStatus("complete");
          ChessSounds.promote();
          setSolved((prev) => new Set(prev).add(currentPuzzle.id));
          setStreak((s) => s + 1);
          return;
        }

        // Play opponent's response after a delay
        setMoveIndex(nextMoveIdx);
        setTimeout(() => {
          const opponentUCI = currentPuzzle.solution[nextMoveIdx];
          if (opponentUCI) {
            const opp = parseUCI(opponentUCI);
            const g2 = new Chess(g.fen());
            const oppResult = g2.move({ from: opp.from, to: opp.to, promotion: opp.promotion as any });
            if (oppResult) {
              if (g2.isCheck()) ChessSounds.check();
              else if (oppResult.captured) ChessSounds.capture();
              else ChessSounds.move();
              setGame(g2);
              setLastMove({ from: opp.from, to: opp.to });
              setMoveIndex(nextMoveIdx + 1);

              // Check again if puzzle complete after opponent move
              if (nextMoveIdx + 1 >= currentPuzzle.solution.length) {
                setStatus("complete");
                ChessSounds.promote();
                setSolved((prev) => new Set(prev).add(currentPuzzle.id));
                setStreak((s) => s + 1);
              }
            }
          }
        }, 400);
      } else {
        // Wrong move
        setStatus("wrong");
        ChessSounds.illegal();
        setStreak(0);
        setSelectedSquare(null);
        setValidMoves([]);

        // Reset after a moment
        setTimeout(() => {
          setStatus("solving");
        }, 1200);
      }
    },
    [game, currentPuzzle, moveIndex, status]
  );

  const handleSquareClick = (square: Square) => {
    if (!game || status !== "solving" || dragging) return;
    const playerColor = currentPuzzle.playerColor;
    const piece = game.get(square);

    if (selectedSquare) {
      if (validMoves.includes(square)) {
        executePlayerMove(selectedSquare, square);
        return;
      }
    }

    if (piece && piece.color === playerColor) {
      setSelectedSquare(square);
      const moves = game.moves({ square, verbose: true });
      setValidMoves(moves.map((m) => m.to as Square));
    } else {
      setSelectedSquare(null);
      setValidMoves([]);
    }
  };

  // Drag handlers
  const handleDragStart = (square: Square, e: React.MouseEvent | React.TouchEvent) => {
    if (!game || status !== "solving") return;
    const piece = game.get(square);
    if (!piece || piece.color !== currentPuzzle.playerColor) return;

    e.preventDefault();
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;

    setDragging({ square, piece: { color: piece.color, type: piece.type }, x: clientX, y: clientY });
    setSelectedSquare(square);
    const moves = game.moves({ square, verbose: true });
    setValidMoves(moves.map((m) => m.to as Square));
  };

  useEffect(() => {
    if (!dragging) return;

    const handleMove = (e: MouseEvent | TouchEvent) => {
      const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
      const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;
      setDragging((prev) => (prev ? { ...prev, x: clientX, y: clientY } : null));
      if (boardRef.current) {
        const sq = getSquareFromPoint(boardRef.current, clientX, clientY, flipped);
        setDragOver(sq);
      }
    };

    const handleEnd = (e: MouseEvent | TouchEvent) => {
      if (!dragging || !boardRef.current) {
        setDragging(null);
        setDragOver(null);
        return;
      }
      const clientX = "changedTouches" in e ? e.changedTouches[0].clientX : e.clientX;
      const clientY = "changedTouches" in e ? e.changedTouches[0].clientY : e.clientY;
      const targetSquare = getSquareFromPoint(boardRef.current, clientX, clientY, flipped);

      if (targetSquare && validMoves.includes(targetSquare)) {
        executePlayerMove(dragging.square, targetSquare);
      } else {
        ChessSounds.illegal();
      }

      setDragging(null);
      setDragOver(null);
    };

    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseup", handleEnd);
    window.addEventListener("touchmove", handleMove, { passive: false });
    window.addEventListener("touchend", handleEnd);
    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseup", handleEnd);
      window.removeEventListener("touchmove", handleMove);
      window.removeEventListener("touchend", handleEnd);
    };
  }, [dragging, validMoves, executePlayerMove, flipped]);

  const nextPuzzle = () => {
    setPuzzleIndex((i) => (i + 1) % filteredPuzzles.length);
  };

  const retryPuzzle = () => {
    if (!currentPuzzle) return;
    const g = new Chess(currentPuzzle.fen);
    setGame(g);
    setMoveIndex(0);
    setSelectedSquare(null);
    setValidMoves([]);
    setLastMove(null);
    setStatus("solving");
    setShowHint(false);
  };

  if (!game || !currentPuzzle) return null;

  const displayGame = game;
  const diffColor =
    currentPuzzle.difficulty === "easy"
      ? "text-emerald-400"
      : currentPuzzle.difficulty === "medium"
      ? "text-gold"
      : "text-destructive";

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border/50 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto flex items-center gap-4 px-6 py-4">
          <Link
            to="/play"
            className="flex items-center gap-2 font-body text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Link>
          <h1 className="font-display text-xl font-semibold">
            Chess <span className="text-gradient-gold">Puzzles</span>
          </h1>
          <div className="ml-auto flex items-center gap-3">
            {streak > 0 && (
              <div className="flex items-center gap-1 font-body text-sm font-semibold text-gold">
                <Flame className="w-4 h-4" />
                {streak}
              </div>
            )}
            <span className="font-body text-xs text-muted-foreground border border-border rounded-full px-3 py-1">
              {solved.size}/{PUZZLES.length} solved
            </span>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left — Categories */}
          <div className="lg:col-span-3 space-y-4 order-2 lg:order-1">
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-display text-sm font-semibold mb-3 text-muted-foreground uppercase tracking-wider">
                Categories
              </h3>
              <div className="space-y-1">
                {CATEGORIES.map((cat) => {
                  const count =
                    cat.id === "all"
                      ? PUZZLES.length
                      : PUZZLES.filter((p) => p.category === cat.id).length;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setCategory(cat.id);
                        setPuzzleIndex(0);
                      }}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm font-body transition-colors ${
                        category === cat.id
                          ? "bg-secondary text-foreground border border-border"
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                      }`}
                    >
                      <cat.icon className="w-4 h-4 text-gold" />
                      {cat.label}
                      <span className="ml-auto text-xs text-muted-foreground">{count}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Puzzle info */}
            <div className="rounded-lg border border-border bg-card p-5">
              <h3 className="font-display text-base font-semibold mb-1">
                {currentPuzzle.title}
              </h3>
              <p className="font-body text-sm text-muted-foreground mb-3">
                {currentPuzzle.description}
              </p>
              <div className="flex items-center gap-2 mb-4">
                <span className={`text-xs font-semibold uppercase ${diffColor}`}>
                  {currentPuzzle.difficulty}
                </span>
                <span className="text-xs text-muted-foreground">·</span>
                <span className="text-xs text-muted-foreground">{currentPuzzle.category}</span>
                <span className="text-xs text-muted-foreground">·</span>
                <span className="text-xs text-muted-foreground">
                  {currentPuzzle.playerColor === "w" ? "White" : "Black"} to move
                </span>
              </div>

              {/* Hint */}
              <button
                onClick={() => setShowHint(!showHint)}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-md border border-border text-sm font-body text-muted-foreground hover:text-foreground transition-colors mb-3"
              >
                <Lightbulb className="w-4 h-4 text-gold" />
                {showHint ? "Hide Hint" : "Show Hint"}
              </button>
              <AnimatePresence>
                {showHint && (
                  <motion.p
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="font-body text-sm text-gold/80 italic"
                  >
                    💡 {currentPuzzle.hint}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Center — Board */}
          <div className="lg:col-span-6 flex flex-col items-center order-1 lg:order-2">
            <div className="relative rounded-lg overflow-hidden border border-border shadow-elevated w-full max-w-[600px]">
              <div
                ref={boardRef}
                className="grid grid-cols-8 grid-rows-8 aspect-square w-full"
              >
                {Array.from({ length: 64 }, (_, i) => {
                  let row = Math.floor(i / 8);
                  let col = i % 8;
                  const displayRow = flipped ? 7 - row : row;
                  const displayCol = flipped ? 7 - col : col;
                  const square = `${String.fromCharCode(97 + displayCol)}${8 - displayRow}` as Square;
                  const piece = displayGame.get(square);
                  const isDark = (displayRow + displayCol) % 2 === 1;
                  const isSelected = selectedSquare === square;
                  const isValidTarget = validMoves.includes(square);
                  const isLastMoveSquare =
                    lastMove?.from === square || lastMove?.to === square;
                  const isDragSource = dragging?.square === square;
                  const isDragTarget = dragOver === square && isValidTarget;

                  return (
                    <div
                      key={square}
                      onClick={() => handleSquareClick(square)}
                      onMouseDown={(e) => handleDragStart(square, e)}
                      onTouchStart={(e) => handleDragStart(square, e)}
                      className={`relative flex items-center justify-center select-none transition-colors ${
                        isDark
                          ? "bg-chess-dark hover:brightness-110"
                          : "bg-chess-light hover:brightness-105"
                      } ${
                        piece && piece.color === currentPuzzle.playerColor && status === "solving"
                          ? "cursor-grab"
                          : "cursor-pointer"
                      }`}
                    >
                      {isLastMoveSquare && (
                        <div
                          className={`absolute inset-0 ${
                            isDark ? "bg-gold/25" : "bg-gold/20"
                          }`}
                        />
                      )}
                      {isSelected && (
                        <div className="absolute inset-0 bg-gold/40 z-10" />
                      )}
                      {isDragTarget && (
                        <div className="absolute inset-0 bg-gold/30 z-10" />
                      )}

                      {/* Coords */}
                      {col === 0 && (
                        <span
                          className={`absolute top-0.5 left-1 text-[9px] font-bold z-10 ${
                            isDark ? "text-chess-light/80" : "text-chess-dark/80"
                          }`}
                        >
                          {8 - displayRow}
                        </span>
                      )}
                      {row === 7 && (
                        <span
                          className={`absolute bottom-0 right-1 text-[9px] font-bold z-10 ${
                            isDark ? "text-chess-light/80" : "text-chess-dark/80"
                          }`}
                        >
                          {String.fromCharCode(97 + displayCol)}
                        </span>
                      )}

                      {piece && !isDragSource && (
                        <img
                          src={PIECE_URLS[piece.color][piece.type]}
                          alt={`${piece.color} ${piece.type}`}
                          className={`w-[82%] h-[82%] object-contain drop-shadow-md select-none pointer-events-none z-20 transition-transform duration-150 ${
                            isSelected ? "scale-110 drop-shadow-xl" : ""
                          }`}
                          draggable={false}
                        />
                      )}

                      {isValidTarget && !isDragTarget && (
                        <div className="absolute z-30 flex items-center justify-center w-full h-full pointer-events-none">
                          {piece && !isDragSource ? (
                            <div className="w-[82%] h-[82%] rounded-full border-[5px] border-foreground/20" />
                          ) : (
                            <div className="w-[30%] h-[30%] rounded-full bg-foreground/20" />
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Dragged piece ghost */}
              {dragging && (
                <div
                  className="fixed pointer-events-none z-[100]"
                  style={{
                    left: dragging.x - 36,
                    top: dragging.y - 36,
                    width: 72,
                    height: 72,
                  }}
                >
                  <img
                    src={PIECE_URLS[dragging.piece.color][dragging.piece.type]}
                    alt="dragging"
                    className="w-full h-full object-contain drop-shadow-xl opacity-90"
                    draggable={false}
                  />
                </div>
              )}

              {/* Status overlays */}
              <AnimatePresence>
                {status === "wrong" && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-50 bg-destructive/20 backdrop-blur-sm flex items-center justify-center"
                  >
                    <div className="flex items-center gap-2 bg-card border border-destructive/50 rounded-lg px-6 py-3">
                      <XCircle className="w-5 h-5 text-destructive" />
                      <span className="font-display text-lg font-bold text-destructive">
                        Wrong move!
                      </span>
                    </div>
                  </motion.div>
                )}
                {status === "complete" && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-50 bg-background/80 backdrop-blur-sm flex flex-col items-center justify-center gap-4"
                  >
                    <CheckCircle className="w-12 h-12 text-emerald-400" />
                    <p className="font-display text-2xl font-bold text-foreground">
                      Puzzle Solved!
                    </p>
                    <div className="flex gap-3">
                      <button
                        onClick={retryPuzzle}
                        className="flex items-center gap-2 px-4 py-2 rounded-md border border-border bg-card hover:bg-secondary transition-colors font-body text-sm"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Retry
                      </button>
                      <button
                        onClick={nextPuzzle}
                        className="flex items-center gap-2 bg-gradient-gold px-6 py-2 rounded-md font-body text-sm font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-105"
                      >
                        Next Puzzle
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Status bar */}
            <div className="mt-4 flex gap-2 w-full justify-center max-w-[600px]">
              <button
                onClick={retryPuzzle}
                className="p-3 bg-card rounded-lg hover:bg-secondary transition-colors border border-border"
                title="Retry puzzle"
              >
                <RotateCcw className="w-4 h-4 text-muted-foreground" />
              </button>
              <div className="flex-1 flex items-center justify-center bg-card rounded-lg px-6 font-body text-sm font-medium border border-border text-foreground">
                {status === "solving" && (
                  <>
                    <span>{currentPuzzle.playerColor === "w" ? "White" : "Black"} to move</span>
                    <span className="ml-2 text-muted-foreground">
                      — Find the best move!
                    </span>
                  </>
                )}
                {status === "wrong" && (
                  <span className="text-destructive">Try again...</span>
                )}
                {status === "complete" && (
                  <span className="text-emerald-400">✓ Solved!</span>
                )}
              </div>
              <button
                onClick={nextPuzzle}
                className="p-3 bg-card rounded-lg hover:bg-secondary transition-colors border border-border"
                title="Skip puzzle"
              >
                <SkipForward className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          </div>

          {/* Right — Progress */}
          <div className="lg:col-span-3 space-y-4 order-3">
            <div className="rounded-lg border border-border bg-card p-5">
              <h3 className="font-display text-base font-semibold mb-4 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-gold" />
                Progress
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between font-body text-sm">
                  <span className="text-muted-foreground">Solved</span>
                  <span className="font-semibold text-foreground">
                    {solved.size}/{PUZZLES.length}
                  </span>
                </div>
                <div className="w-full bg-secondary rounded-full h-2">
                  <div
                    className="bg-gradient-gold h-2 rounded-full transition-all duration-500"
                    style={{
                      width: `${(solved.size / PUZZLES.length) * 100}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between font-body text-sm">
                  <span className="text-muted-foreground">Current Streak</span>
                  <span className="font-semibold text-gold flex items-center gap-1">
                    <Flame className="w-3 h-3" />
                    {streak}
                  </span>
                </div>
              </div>
            </div>

            {/* Puzzle list */}
            <div className="rounded-lg border border-border bg-card p-4 max-h-[400px] overflow-y-auto scrollbar-hide">
              <h3 className="font-display text-sm font-semibold mb-3 text-muted-foreground uppercase tracking-wider">
                Puzzles
              </h3>
              <div className="space-y-1">
                {filteredPuzzles.map((p, i) => (
                  <button
                    key={p.id}
                    onClick={() => setPuzzleIndex(i)}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm font-body transition-colors text-left ${
                      puzzleIndex % filteredPuzzles.length === i
                        ? "bg-secondary text-foreground border border-border"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                    }`}
                  >
                    {solved.has(p.id) ? (
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    ) : (
                      <Target className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                    )}
                    <span className="truncate">{p.title}</span>
                    <span
                      className={`ml-auto text-[10px] font-semibold uppercase ${
                        p.difficulty === "easy"
                          ? "text-emerald-400"
                          : p.difficulty === "medium"
                          ? "text-gold"
                          : "text-destructive"
                      }`}
                    >
                      {p.difficulty}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Puzzles;
