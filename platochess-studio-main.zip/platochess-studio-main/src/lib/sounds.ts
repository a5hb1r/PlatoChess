// Chess.com-style move sounds using Web Audio API synthesis
// Produces realistic wooden piece placement, captures, and alert tones

let ctx: AudioContext | null = null;

function getCtx(): AudioContext {
  if (!ctx) ctx = new AudioContext();
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function createNoise(duration: number, sampleRate: number): AudioBuffer {
  const buffer = new AudioBuffer({ length: Math.floor(sampleRate * duration), sampleRate });
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i++) {
    data[i] = Math.random() * 2 - 1;
  }
  return buffer;
}

function playNoiseBurst(
  freq: number,
  duration: number,
  volume: number,
  filterQ = 1
) {
  const c = getCtx();
  const t = c.currentTime;

  const src = c.createBufferSource();
  src.buffer = createNoise(duration, c.sampleRate);

  const bp = c.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.setValueAtTime(freq, t);
  bp.Q.setValueAtTime(filterQ, t);

  const g = c.createGain();
  g.gain.setValueAtTime(volume, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + duration);

  src.connect(bp).connect(g).connect(c.destination);
  src.start(t);
  src.stop(t + duration);
}

function playTone(
  freq: number,
  duration: number,
  type: OscillatorType,
  volume: number,
  delay = 0
) {
  const c = getCtx();
  const t = c.currentTime + delay;

  const osc = c.createOscillator();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);

  const g = c.createGain();
  g.gain.setValueAtTime(volume, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + duration);

  osc.connect(g).connect(c.destination);
  osc.start(t);
  osc.stop(t + duration);
}

export const ChessSounds = {
  /** Standard piece placement — woody click */
  move() {
    playNoiseBurst(800, 0.06, 0.18, 2);
    playTone(220, 0.04, "sine", 0.06);
  },

  /** Piece capture — sharp impact */
  capture() {
    playNoiseBurst(600, 0.1, 0.3, 1.5);
    playNoiseBurst(1200, 0.04, 0.12, 3);
    playTone(180, 0.08, "triangle", 0.1);
  },

  /** Check — two-note alert */
  check() {
    playTone(880, 0.07, "sine", 0.15);
    playTone(1175, 0.1, "sine", 0.12, 0.07);
  },

  /** Castling — double woody click */
  castle() {
    playNoiseBurst(900, 0.05, 0.16, 2);
    playNoiseBurst(700, 0.06, 0.2, 2);
    playTone(260, 0.04, "sine", 0.05, 0.08);
  },

  /** Game over — descending chord */
  gameOver() {
    playTone(660, 0.2, "sine", 0.12);
    playTone(523, 0.2, "sine", 0.1, 0.15);
    playTone(392, 0.35, "sine", 0.1, 0.3);
  },

  /** Pawn promotion — ascending sparkle */
  promote() {
    playTone(523, 0.08, "sine", 0.1);
    playTone(659, 0.08, "sine", 0.1, 0.07);
    playTone(784, 0.08, "sine", 0.1, 0.14);
    playTone(1047, 0.15, "sine", 0.12, 0.21);
  },

  /** Illegal move / error */
  illegal() {
    playTone(200, 0.15, "square", 0.08);
    playTone(160, 0.2, "square", 0.06, 0.1);
  },
};
