// Stockfish WASM worker wrapper
// Uses the stockfish.js WASM build from CDN

type StockfishCallback = (info: StockfishInfo) => void;

export interface StockfishInfo {
  depth?: number;
  score?: number; // centipawns from white's perspective
  mate?: number;
  bestMove?: string;
  pv?: string;
}

export class StockfishEngine {
  private worker: Worker | null = null;
  private onInfo: StockfishCallback | null = null;
  private onBestMove: ((move: string) => void) | null = null;
  private ready = false;

  async init() {
    if (this.worker) return;

    // Use stockfish.js WASM from CDN
    const workerCode = `importScripts('https://cdn.jsdelivr.net/npm/stockfish@16.0.0/src/stockfish-nnue-16.js');`;
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    this.worker = new Worker(URL.createObjectURL(blob));

    return new Promise<void>((resolve) => {
      this.worker!.onmessage = (e) => {
        const line = typeof e.data === 'string' ? e.data : '';
        
        if (line.includes('uciok')) {
          this.ready = true;
          this.worker!.postMessage('isready');
        }
        
        if (line.includes('readyok')) {
          resolve();
        }

        this.handleMessage(line);
      };

      this.worker!.postMessage('uci');
    });
  }

  private handleMessage(line: string) {
    // Parse eval info
    if (line.startsWith('info') && line.includes('score')) {
      const info: StockfishInfo = {};
      
      const depthMatch = line.match(/depth (\d+)/);
      if (depthMatch) info.depth = parseInt(depthMatch[1]);

      const cpMatch = line.match(/score cp (-?\d+)/);
      if (cpMatch) info.score = parseInt(cpMatch[1]);

      const mateMatch = line.match(/score mate (-?\d+)/);
      if (mateMatch) info.mate = parseInt(mateMatch[1]);

      const pvMatch = line.match(/pv (.+)/);
      if (pvMatch) info.pv = pvMatch[1].split(' ')[0];

      if (this.onInfo && (info.score !== undefined || info.mate !== undefined)) {
        this.onInfo(info);
      }
    }

    // Parse best move
    if (line.startsWith('bestmove')) {
      const move = line.split(' ')[1];
      if (move && this.onBestMove) {
        this.onBestMove(move);
      }
    }
  }

  setSkillLevel(level: number) {
    // Level 0-20
    if (!this.worker) return;
    this.worker.postMessage(`setoption name Skill Level value ${level}`);
  }

  setDepthLimit(depth: number) {
    // Used alongside skill level for weaker play
    if (!this.worker) return;
    this.worker.postMessage(`setoption name Skill Level Maximum Error value ${depth > 10 ? 100 : 900 - depth * 80}`);
    this.worker.postMessage(`setoption name Skill Level Probability value ${depth > 10 ? 200 : 50 + depth * 15}`);
  }

  evaluate(fen: string, depth: number = 18, callback: StockfishCallback) {
    if (!this.worker) return;
    this.onInfo = callback;
    this.worker.postMessage('stop');
    this.worker.postMessage(`position fen ${fen}`);
    this.worker.postMessage(`go depth ${depth}`);
  }

  getBestMove(fen: string, depth: number = 12): Promise<string> {
    return new Promise((resolve) => {
      if (!this.worker) return resolve('');
      this.onBestMove = resolve;
      this.worker.postMessage('stop');
      this.worker.postMessage(`position fen ${fen}`);
      this.worker.postMessage(`go depth ${depth}`);
    });
  }

  stop() {
    if (this.worker) {
      this.worker.postMessage('stop');
    }
  }

  destroy() {
    if (this.worker) {
      this.worker.postMessage('quit');
      this.worker.terminate();
      this.worker = null;
    }
  }
}
