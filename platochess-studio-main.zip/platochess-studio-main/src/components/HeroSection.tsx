import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import heroImg from "@/assets/hero-chess.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={heroImg}
          alt="Chess pieces on a board"
          className="h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 text-center pt-24">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-body text-sm uppercase tracking-[0.3em] text-gold mb-6"
        >
          Pure Chess Improvement
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="font-display text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.95] mb-6"
        >
          Master the
          <br />
          <span className="text-gradient-gold italic">Art of Chess</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="font-body text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          No distractions. No gimmicks. Just deep, focused training designed to
          elevate your game from where you are to where you want to be.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link to="/play" className="bg-gradient-gold px-8 py-3.5 rounded-md font-body text-base font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-105">
            Begin Your Journey
          </Link>
          <a href="#method" className="border border-border px-8 py-3.5 rounded-md font-body text-base text-foreground transition-colors hover:bg-secondary">
            See How It Works
          </a>
        </motion.div>

        {/* Chessboard pattern accent */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.2 }}
          transition={{ duration: 1, delay: 1.3 }}
          className="mt-20 flex justify-center gap-1"
        >
          {Array.from({ length: 8 }).map((_, row) => (
            <div key={row} className="flex flex-col gap-1">
              {Array.from({ length: 3 }).map((_, col) => (
                <div
                  key={col}
                  className={`h-4 w-4 rounded-sm ${
                    (row + col) % 2 === 0 ? "bg-chess-light" : "bg-chess-dark"
                  }`}
                />
              ))}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
