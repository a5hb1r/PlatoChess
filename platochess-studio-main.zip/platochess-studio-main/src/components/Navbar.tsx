import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { LogOut, Settings, LayoutDashboard } from "lucide-react";
import logo from "@/assets/platochess-logo.png";

const Navbar = () => {
  const { user, signOut } = useAuth();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto flex items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-3">
          <img src={logo} alt="Platochess" className="h-8 w-8" />
          <span className="font-display text-xl font-semibold text-foreground">
            Plato<span className="text-gradient-gold">chess</span>
          </span>
        </Link>
        <div className="hidden md:flex items-center gap-8 font-body text-sm text-muted-foreground">
          <a href="#features" className="transition-colors hover:text-foreground">Features</a>
          <a href="#method" className="transition-colors hover:text-foreground">Method</a>
          <a href="#pricing" className="transition-colors hover:text-foreground">Pricing</a>
        </div>
        <div className="flex items-center gap-3">
          {user ? (
            <>
              <Link
                to="/play"
                className="bg-gradient-gold px-5 py-2 rounded-md font-body text-sm font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-105"
              >
                Play Now
              </Link>
              <Link
                to="/dashboard"
                className="flex items-center gap-2 border border-border px-3 py-2 rounded-md font-body text-sm text-muted-foreground transition-colors hover:text-foreground hover:bg-secondary"
                title="Dashboard"
              >
                <LayoutDashboard className="h-4 w-4" />
              </Link>
              <Link
                to="/settings"
                className="flex items-center gap-2 border border-border px-3 py-2 rounded-md font-body text-sm text-muted-foreground transition-colors hover:text-foreground hover:bg-secondary"
                title="Account Settings"
              >
                <Settings className="h-4 w-4" />
              </Link>
              <button
                onClick={signOut}
                className="flex items-center gap-2 border border-border px-3 py-2 rounded-md font-body text-sm text-muted-foreground transition-colors hover:text-foreground hover:bg-secondary"
                title="Sign Out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <Link
              to="/auth"
              className="bg-gradient-gold px-5 py-2 rounded-md font-body text-sm font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-105"
            >
              Start Training
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
